package com.thilini.springBatch.listeners;

import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.annotation.AfterChunk;
import org.springframework.batch.core.annotation.AfterChunkError;
import org.springframework.batch.core.annotation.BeforeChunk;
import org.springframework.batch.core.scope.context.ChunkContext;

public class itemChunkListener implements ChunkListener {

	@BeforeChunk
	public void beforeChunk(ChunkContext context) {
		System.out.println("At before Chunk"+ context+"....................");
		
	}

	@AfterChunk
	public void afterChunk(ChunkContext context) {
		System.out.println("At after Chunk"+ context+"....................");
		
	}

	@AfterChunkError
	public void afterChunkError(ChunkContext context) {
		System.out.println("At after Chunk error!!!!"+ context+"....................");
		
	}

}
