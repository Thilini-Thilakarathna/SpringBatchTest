package com.thilini.springBatch.model;

import java.time.LocalDateTime;

public class item {

	public item() {
		super();
	}
	Integer iditem;
	public Integer getIditem() {
		return iditem;
	}
	public String getCategory() {
		return category;
	}
	public String getType() {
		return type;
	}
	public LocalDateTime getExpire_date() {
		return expire_date;
	}
	public String getName() {
		return name;
	}
	public double getPrice() {
		return price;
	}
	public String getStock_id() {
		return stock_id;
	}
	public Integer getSup_id() {
		return sup_id;
	}
	public void setIditem(Integer iditem) {
		this.iditem = iditem;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setExpire_date(LocalDateTime expire_date) {
		this.expire_date = expire_date;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void setStock_id(String stock_id) {
		this.stock_id = stock_id;
	}
	public void setSup_id(Integer sup_id) {
		this.sup_id = sup_id;
	}
	String category;
	String type;
	LocalDateTime expire_date;
	String name;
	double price;
	String stock_id;
	Integer sup_id;
	String description;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
}
