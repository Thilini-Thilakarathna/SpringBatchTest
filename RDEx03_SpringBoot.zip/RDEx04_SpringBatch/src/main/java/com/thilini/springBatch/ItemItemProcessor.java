package com.thilini.springBatch;

import java.awt.event.ItemListener;

import javax.batch.api.chunk.listener.ItemProcessListener;

import org.springframework.batch.core.annotation.AfterProcess;
import org.springframework.batch.core.annotation.BeforeProcess;
import org.springframework.batch.core.annotation.OnProcessError;
import org.springframework.batch.item.ItemProcessor;

import com.thilini.springBatch.model.item;

public class ItemItemProcessor implements ItemProcessor<item, item>,ItemProcessListener{

	@Override
	public item process(item ite) throws Exception {
		
		return ite;
	}

	@BeforeProcess
	public void beforeProcess(Object item) throws Exception {
		System.out.println("At before process"+item+"....................");
		
	}

	@AfterProcess
	public void afterProcess(Object item, Object result) throws Exception {
		System.out.println("At after process Result is..."+result+"....................");
		
	}

	@OnProcessError
	public void onProcessError(Object item, Exception ex) throws Exception {
		System.out.println("At Process Error !! error is ...."+ex+"....................");
		
	}
	

}
