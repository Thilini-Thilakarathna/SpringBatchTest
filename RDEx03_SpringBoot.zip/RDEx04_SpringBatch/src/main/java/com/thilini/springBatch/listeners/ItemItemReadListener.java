package com.thilini.springBatch.listeners;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.annotation.AfterRead;
import org.springframework.batch.core.annotation.BeforeRead;
import org.springframework.batch.core.annotation.OnReadError;

import com.thilini.springBatch.model.item;

public class ItemItemReadListener implements ItemReadListener<item>{

	@BeforeRead
	public void beforeRead() {
		System.out.println("At before read....................");
		
	}

	@AfterRead
	public void afterRead(item item) {
		System.out.println("At after read"+item+"....................");
		
	}

	@OnReadError
	public void onReadError(Exception ex) {
		System.out.println("At onRead Erroe"+ex+"....................");
		
	}

}
