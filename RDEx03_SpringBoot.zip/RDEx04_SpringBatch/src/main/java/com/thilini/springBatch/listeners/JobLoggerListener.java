package com.thilini.springBatch.listeners;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.annotation.AfterJob;
import org.springframework.batch.core.annotation.BeforeJob;
import org.springframework.stereotype.Component;



@Component
public class JobLoggerListener implements JobExecutionListener{

	@BeforeJob
	public void beforeJob(JobExecution jobExecution) {
		System.out.println(jobExecution.getJobInstance().getJobName()+"is beginning Execution........");
		
	}

	@AfterJob
	public void afterJob(JobExecution jobExecution) {
		System.out.println(jobExecution.getJobInstance().getJobName()+"has completed with status..."+jobExecution.getStatus());
		
	}


}
