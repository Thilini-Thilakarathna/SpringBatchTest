package com.thilini.springBatch.RowMappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.thilini.springBatch.model.item;

public class itemRowMapper implements RowMapper<item>{

	@Override
	public item mapRow(ResultSet rs, int rowNum) throws SQLException {
		item item1= new item();
		item1.setIditem(rs.getInt("iditem"));
		item1.setName(rs.getString("name"));
		item1.setDescription(rs.getString("description"));
		item1.setExpire_date(rs.getTimestamp("expire_date").toLocalDateTime());
		item1.setPrice(rs.getDouble("price"));
		item1.setCategory(rs.getString("category"));
		item1.setType(rs.getString("type"));
		item1.setStock_id(rs.getString("stock_id"));
		item1.setSup_id(rs.getInt("sup_id"));
		
		
		return item1;
		
	}
	
	

}
