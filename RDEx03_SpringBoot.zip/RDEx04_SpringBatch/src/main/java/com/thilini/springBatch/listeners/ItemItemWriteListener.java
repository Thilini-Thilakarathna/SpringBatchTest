package com.thilini.springBatch.listeners;

import java.util.List;

import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.annotation.AfterWrite;
import org.springframework.batch.core.annotation.BeforeWrite;
import org.springframework.batch.core.annotation.OnWriteError;

import com.thilini.springBatch.model.item;

public class ItemItemWriteListener implements ItemWriteListener<item> {

	@BeforeWrite
	public void beforeWrite(List<? extends item> items) {
		System.out.println("At before write"+items+"....................");
		
	}

	@AfterWrite
	public void afterWrite(List<? extends item> items) {
		System.out.println("At after write"+items+"....................");
		
	}

	@OnWriteError
	public void onWriteError(Exception exception, List<? extends item> items) {
		System.out.println("At write error !!! error is...."+exception+"....................");
		
	}

}
