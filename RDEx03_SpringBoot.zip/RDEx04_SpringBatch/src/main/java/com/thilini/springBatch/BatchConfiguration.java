package com.thilini.springBatch;

import javax.annotation.PostConstruct;
import javax.batch.api.listener.StepListener;
import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.annotation.AfterJob;
import org.springframework.batch.core.annotation.BeforeJob;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

import com.thilini.springBatch.RowMappers.itemRowMapper;
import com.thilini.springBatch.listeners.ItemItemReadListener;
import com.thilini.springBatch.listeners.ItemItemWriteListener;
import com.thilini.springBatch.listeners.JobLoggerListener;
import com.thilini.springBatch.listeners.itemChunkListener;

import com.thilini.springBatch.listeners.itemSkipInListener;
import com.thilini.springBatch.listeners.itemStepExecutionListener;
import com.thilini.springBatch.model.item;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	

	
	
	@Autowired
	public JobBuilderFactory jobbuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;


	@Autowired
	public DataSource datasource;
	
	@Autowired
	public JobExecutionListener jobExecutionlistener;
	
   
	@Bean
    public DataSource dataSource() {

	final	DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/assignmentdb");
		dataSource.setUsername("root");
		dataSource.setPassword("");
		System.out.println(dataSource);
		return dataSource;
		
	}
	
	@Bean
	public JdbcCursorItemReader<item> reader(){
		JdbcCursorItemReader<item> reader= new JdbcCursorItemReader<item>();
		reader.setDataSource(datasource);
		reader.setSql("select * from item");
		reader.setRowMapper(new itemRowMapper());
		
		return reader;
	}
	
	

	public ItemItemProcessor processor() {
		return new ItemItemProcessor();
	}
	
	@Bean
	public FlatFileItemWriter<item> writer(){
		FlatFileItemWriter<item> writer= new FlatFileItemWriter<item>();
		writer.setResource(new ClassPathResource("item.csv"));
		writer.setLineAggregator(new DelimitedLineAggregator<item>() {{
			setDelimiter(",");
			setFieldExtractor(new BeanWrapperFieldExtractor<item>() {{
				setNames(new String[] {"iditem","name","description","expire_date","category","type","price","stock_id","sup_id"});
			}});
		}});
		
		return writer;
		
	}
	
	@Bean
	public Step step1() {
		return ((SimpleStepBuilder<item, item>) stepBuilderFactory.get("step1").<item,item>chunk(10)
				.listener(new itemChunkListener())
				.listener(new itemStepExecutionListener()))
				
			
				.reader(reader())
				.listener(new ItemItemReadListener())
				
				.processor(processor())
				
				.writer(writer())
				.listener(new ItemItemWriteListener())
				.listener(new itemSkipInListener())
				.build();
	}
	
	@Bean
	public Job exportitemJob() {
		return jobbuilderFactory.get("exportitemJob")
				
				.incrementer(new RunIdIncrementer())
				.listener(new JobLoggerListener())
				
				.flow(step1())
				
				.end()
				.build();
				
	}
	

	
	
	

}
