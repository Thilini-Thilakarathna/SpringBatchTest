package com.thilini.springBatch.listeners;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;

public class itemStepExecutionListener implements StepExecutionListener {

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		System.out.println("At before step"+stepExecution+"....................");
		
	}

	@AfterStep
	public ExitStatus afterStep(StepExecution stepExecution) {
		System.out.println("At after step"+stepExecution+"....................");
		return null;
	}

}
