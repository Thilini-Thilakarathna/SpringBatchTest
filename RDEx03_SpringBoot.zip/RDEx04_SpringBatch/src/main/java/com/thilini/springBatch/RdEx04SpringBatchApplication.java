package com.thilini.springBatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RdEx04SpringBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(RdEx04SpringBatchApplication.class, args);
	}

}
