package com.thilini.springBatch.listeners;

import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.annotation.OnSkipInProcess;
import org.springframework.batch.core.annotation.OnSkipInRead;
import org.springframework.batch.core.annotation.OnSkipInWrite;

import com.thilini.springBatch.model.item;

public class itemSkipInListener implements SkipListener<item, item>{

	@OnSkipInRead
	public void onSkipInRead(Throwable t) {
		System.out.println("At on skip in read"+t+"....................");
		
	}

	@OnSkipInWrite
	public void onSkipInWrite(item item, Throwable t) {
		System.out.println("At on skip in write"+item+t+"....................");
		
	}

	@OnSkipInProcess
	public void onSkipInProcess(item item, Throwable t) {
		System.out.println("At on skipm in process"+item+t+"....................");
		
	}

}
