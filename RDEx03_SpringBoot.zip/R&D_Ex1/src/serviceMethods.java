import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import DB.dbClass;
import beanClasses.item;

public class serviceMethods {
	static ArrayList<item> itemList; 
	
	public static ArrayList<item> getAllItem(){
		itemList = new ArrayList<>();
		try {

			ResultSet rs= dbClass.getCon("select * from item");
			
			while(rs.next()) {
				
//				java.sql.Timestamp d= rs.getTimestamp("expire_date");
//				d.toLocalDateTime();
				
				System.out.println(rs.getInt("iditem"));
				
			itemList.add(new item(rs.getInt("iditem"),
					rs.getString("name"), rs.getString("description"),
					rs.getTimestamp("expire_date").toLocalDateTime(),
					rs.getDouble("price"), rs.getString("category"), 
					rs.getString("type"), rs.getString("stockId") 
					))	;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

		return itemList;
	}
	
	public static void addData(item it) {
		try {
			
			dbClass.setCon("insert into item (name,description,expire_date,price,category,type,stock_id) values ('"+it.getName()+"','"+it.getDescription()+"','"+it.getExpire_date()+"',"+it.getPrice()+",'"+it.getCategory()+"','"+it.getType()+"','"+it.getStockId()+"') ");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void SaveCalculateData(){
		try {
			
			
			ResultSet rs1= dbClass.getCon("SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'item' AND COLUMN_NAME = 'stock_out' ");
		
			if (rs1.first()) {
				dbClass.setCon("ALTER TABLE `assignmentdb`.`item` \r\n" + 
						"DROP COLUMN `stock_out`");
			} else {

			}
			
		
			
			
			
			dbClass.setCon("ALTER TABLE `assignmentdb`.`item` \r\n" + 
					"ADD COLUMN `stock_out` VARCHAR(45) NULL AFTER `stock_id`");	
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd'T'HH:mm:ss'z'");
			
		ResultSet rs=	dbClass.getCon("select iditem,expire_date from item");
		while (rs.next()) {
			dbClass.setCon("update item set stock_out='"+rs.getTimestamp("expire_date").toLocalDateTime().minusMonths(2).minusDays(6).format(formatter)+"' where iditem='"+rs.getInt("iditem")+"'");
			
		}
			
			
			
		} catch (Exception e) {
		e.printStackTrace();
		}
	}
	
	
	public static void visualizeData() {
		try {
		
			
			
			File f1= new File("itemList.txt");
			f1.delete();
			FileWriter ff= new FileWriter(f1);
			BufferedWriter buf= new BufferedWriter(ff);
		
//			FileOutputStream fout= new FileOutputStream(f1);
//			ObjectOutputStream bout= new ObjectOutputStream(fout);
			
			ResultSet rs=	dbClass.getCon("select * from item");
			while (rs.next()) {
				System.out.println("-------------------------------");
				
				buf.write("|"+rs.getInt("iditem")+"|"+rs.getString("name")+"|"+rs.getString("description")+"|"+rs.getTimestamp("expire_date")+"|"+rs.getDouble("price")+"|"+rs.getString("category")+"|"+rs.getString("type")+"|"+rs.getString("stock_id")+"|"+rs.getString("stock_out"));
				buf.newLine();
				buf.write("");
				buf.newLine();
			}
			
			
//		ff.write(al.toString());
		buf.close();
			ff.close();
			Desktop des= Desktop.getDesktop();
			des.open(f1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	public static void fetchItemByType(String type) {
		
		
		try {
			
			Map<Object, String> filtered = new HashMap();
			
			File f1= new File("typeList.txt");
			f1.delete();
			FileWriter ff= new FileWriter(f1);
			BufferedWriter buf= new BufferedWriter(ff);
			
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd'T'HH:mm:ss'z'");
			itemList.stream().filter(e-> e.getType().equals(type)).map(e -> new Object[] { e.getId(), e.getName(), e.getDescription(),
							e.getExpire_date().format(formatter), e.getPrice(), e.getCategory(), e.getType(),
							e.getStockId(), }).forEach(e -> filtered.put(e[0], Arrays.toString(e)));
			
		
			
			filtered.entrySet().stream().forEach(e -> {
				try {
					buf.write(e.toString());
					buf.newLine();
					buf.write("");
					buf.newLine();
					
				} catch (IOException e1) {
				
					e1.printStackTrace();
				}
			});
//			buf.write(filtered.toString());
			buf.close();
			ff.close();
			
			Desktop des= Desktop.getDesktop();
			des.open(f1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
