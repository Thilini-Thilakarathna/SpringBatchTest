package DB;

import java.sql.DriverManager;
import java.sql.ResultSet;

public class dbClass {

	
	private static final String Driver= "com.mysql.cj.jdbc.Driver";
	private static final String Url = "jdbc:mysql://localhost:3306/assignmentdb";
	
	private static java.sql.Connection c;
	
	private dbClass() {}
	 
	
	private static java.sql.Connection con() throws Exception{
		
		if(c==null) {
			Class.forName(Driver);
			c= DriverManager.getConnection(Url, "root", "");
		}
		return c;
	}
	
	
	public static void setCon(String qry) throws Exception{
		con().createStatement().executeUpdate(qry);
	}
	
	public static ResultSet getCon(String qry) throws Exception{
		ResultSet rs= con().createStatement().executeQuery(qry);
		
		return rs;
	}
	
}
