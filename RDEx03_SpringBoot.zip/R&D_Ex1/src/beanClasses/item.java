package beanClasses;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class item {

	int id;



	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public LocalDateTime getExpire_date() {
		return expire_date;
	}

	public double getPrice() {
		return price;
	}

	public String getCategory() {
		return category;
	}

	public String getType() {
		return type;
	}

	public String getStockId() {
		return stock_id;
	}

	

	String name;
	String description;
	LocalDateTime expire_date;
	double price;
	String category;
	String type;
	String stock_id;

	
	




	public item(int id, String name, String description, LocalDateTime expire_date, double price, String category,
			String type, String stockId) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.expire_date = expire_date;
		this.price = price;
		this.category = category;
		this.type = type;
		this.stock_id = stockId;
		
	}
	
//	
//	public List getAllItem() {
//		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd'T'HH:mm:ss'z'");
//		List al= new ArrayList();
//		al.add(this.id);
//		al.add(this.name);
//		al.add(this.description);
//				al.add(this.expire_date);
//						al.add(this.price);
//								al.add(this.category);
//										al.add(this.type);
//												al.add(this.stockId);
//														al.add(this.stock_out);
//	
//		return al;
//	
//	}
	
}
