import java.lang.reflect.Array;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import DB.dbClass;
import beanClasses.item;

public class main {

	public static void main(String[] args) {
		List<item> it;
		try {
			
			//to save data
			save();
			
			//to calculate date
			serviceMethods.SaveCalculateData();
			//
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd'T'HH:mm:ss'z'");
			serviceMethods.getAllItem().stream()
					.map(e -> new Object[] { e.getId(), e.getName(), e.getDescription(),
							e.getExpire_date().format(formatter), e.getPrice(), e.getCategory(), e.getType(),
							e.getStockId() })

					.forEach(e -> System.out.println(Arrays.toString(e)));
			// to fetch all item
			serviceMethods.visualizeData();
			
			//fetch item by type
			serviceMethods.fetchItemByType("yougart");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void save() {
		LocalDateTime date = LocalDateTime.now();
//		System.out.println(date.minusMonths(2).minusDays(1));
		ArrayList<item> itm = new ArrayList<item>();
//		String str = "1986-APR-08 12:30";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd'T'HH:mm:ss'z'");
		System.out.println(date.format(formatter));
		;
//	LocalDateTime dateTime = LocalDateTime.parse(date.format(formatter));
//		
		itm.add(new item(0, "Newdale set yogurt", "milk", date, 35.00, "Anchor Newdale", "yougart", "st1"));
//	
		itm.add(new item(0, "Newdale yougart drink", "Strawberry", date, 70.00, "Anchor Newdale", "yougart", "st2"));
		itm.add(new item(0, "Newdale milk powder", "400g", date, 425.00, "Anchor ", "milk poeder", "st4"));

		itm.stream().forEach(ite -> serviceMethods.addData(ite));
	}

}
