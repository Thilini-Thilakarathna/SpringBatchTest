package com.thilini.spring.service;

import java.util.List;

import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;

import com.thilini.spring.model.Supplier;
import com.thilini.spring.model.item;

public interface ItemService {

	public void save(item item);
	
	public item update(item itm,Integer id);
	
	public void delete(Integer id);
	
	public List<item> findi(Integer id);
	
	public List<item> findByType(String type);
	
	public void saveSup(Supplier supplier);
}
