package com.thilini.spring.model;

public class iItemSupplier {

	Integer Id;
	public iItemSupplier(Integer id, Integer itemId, String itemName, Integer supplierId) {
		super();
		Id = id;
		this.itemId = itemId;
		this.itemName = itemName;
		SupplierId = supplierId;
	}
	Integer itemId;
	String itemName;
	Integer SupplierId;
	
	
	
}
