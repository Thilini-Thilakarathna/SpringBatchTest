package com.thilini.spring.repository;

import java.util.List;

import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.Repository;

import com.thilini.spring.model.item;

public interface itemRepoDSL extends Repository<item, Integer>,QuerydslPredicateExecutor<item>{

	
	
	public List<item> findByType(String type);
}
