package com.thilini.spring.service;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.querydsl.core.types.Predicate;
import com.thilini.spring.model.Qitem;
import com.thilini.spring.model.Supplier;
import com.thilini.spring.model.item;
import com.thilini.spring.repository.ItemRepository;
import com.thilini.spring.repository.SupplierRepository;
import com.thilini.spring.repository.itemRepoDSL;




@Service
public class ItemServiceImpl implements ItemService{

	
	@Autowired
	ItemRepository itemRepository;
	
	@Autowired
	itemRepoDSL itemrepo;
	
	@Autowired
	SupplierRepository supplierRepos;
	
	
	@Override
	public void save(item item) {
	itemRepository.save(item);
		
	}

	@Override
	public item update(item itm, Integer id) {
		
		
		return itemRepository.findById(id).map(item1 -> {
			item1.setIditem(itm.getIditem());
			return itemRepository.save(item1);
		}).orElseGet(() -> {
			itm.setIditem(id);
			return itemRepository.save(itm);
		});

	}

	@Override
	public void delete(Integer id) {
	itemRepository.deleteById(id);
		
	}

	@Override
	public List<item> findi(Integer id) {
		System.out.println(itemRepository.findi(id));
		return itemRepository.findi(id);
	}

	@Override
	public List<item> findByType(String type) {
		List <item> itm= new ArrayList<>();
	Qitem qitem= Qitem.item;
	Predicate cnt= qitem.type.contains(type);
	Iterable<item> it= itemrepo.findAll(cnt);
	for (item ite : it) {
		itm.add(ite);
	}
	
	return itm;
	}

	@Override
	public void saveSup(Supplier supplier) {
		supplierRepos.save(supplier);
		
	}

	
	



	
	
}
