package com.thilini.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.thilini.spring.model.Supplier;
import com.thilini.spring.model.item;
import com.thilini.spring.service.ItemService;

@RestController
@RequestMapping(value="/stock")
public class Controller {
	
	@Autowired
	ItemService itemService;
	
	@PostMapping(value = "/item")
	public void save(@RequestBody item it) {
		itemService.save(it);
		
	}
	
	
	@DeleteMapping(value = "/delete/{id}")
	public void delete(@PathVariable Integer id) {
		itemService.delete(id);
	}
	
	@PutMapping(value = "/update/{id}")
	public void update(@RequestBody item itm, @PathVariable Integer id) {
		
		
		itemService.update(itm,id);
		
	}
	
	
	
	@GetMapping(value= "/findtype/{type:.*}")
	public List<item> getItem(@PathVariable String type){
		return itemService.findByType(type);
	}
	
	
	@GetMapping(value= "/findit/{id}")
	public List<item> getItem(@PathVariable Integer id){
		return itemService.findi(id);
	}
	
	@PostMapping(value = "supplier")
	public void saveSup(@RequestBody Supplier supplier) {
		itemService.saveSup(supplier);
	}
	
}
