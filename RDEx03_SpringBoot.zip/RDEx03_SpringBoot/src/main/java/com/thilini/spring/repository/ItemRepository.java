package com.thilini.spring.repository;

import java.util.List;

import javax.validation.constraints.Email;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import com.thilini.spring.model.item;



public interface ItemRepository extends JpaRepository<item, Integer>{

	
@Query("select i from com.thilini.spring.model.item i inner join com.thilini.spring.model.Supplier s on s.id= i.sup_id where s.id= :supId")
List<item> findi(@Param ("supId") Integer supId) ;

}
