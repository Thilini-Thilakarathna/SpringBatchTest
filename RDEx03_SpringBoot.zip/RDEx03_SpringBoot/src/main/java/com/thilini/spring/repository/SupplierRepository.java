package com.thilini.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.thilini.spring.model.Supplier;
import com.thilini.spring.model.item;

public interface SupplierRepository extends JpaRepository<Supplier, Integer>{

}
