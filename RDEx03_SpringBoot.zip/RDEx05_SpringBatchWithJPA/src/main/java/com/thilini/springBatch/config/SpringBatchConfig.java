package com.thilini.springBatch.config;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;

import com.thilini.springBatch.batch.DBWriter;
import com.thilini.springBatch.batch.Processor;
import com.thilini.springBatch.model.item;
import com.thilini.springBatch.repository.ItemRepository;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {

	@Autowired
	public EntityManagerFactory entityManagerFactory;
	
	
	@Autowired
	private ItemRepository itemRepository;

	@Bean
	public Job job(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory
			)
			throws Exception {

		Step step = stepBuilderFactory.get("ETL-file-load").<item, item>chunk(100)

				.reader(fileItemReader()).processor(processer()).writer(new DBWriter()).build();
		

		return jobBuilderFactory.get("ETL-load").incrementer(new RunIdIncrementer()).start(step).build();

	}

	
	@Bean
	public FlatFileItemReader<item> fileItemReader() throws UnexpectedInputException, ParseException, Exception {

		FlatFileItemReader<item> flatFileItemReader = new FlatFileItemReader<item>();
		
		flatFileItemReader.setResource(new ClassPathResource("item.csv"));
		flatFileItemReader.setName("CSV-Reader");
		
		flatFileItemReader.setLineMapper(new DefaultLineMapper<item>() {{
			setLineTokenizer(new DelimitedLineTokenizer() {{
				setNames(new String[] { "iditem", "category", "description", "expire_date", "name", "price",
				"stock_id", "sup_id", "type" });
			}});
			setFieldSetMapper(new BeanWrapperFieldSetMapper<item>() {{
				setTargetType(item.class);
			}});
		}});
		
		return flatFileItemReader;

	}

	
//	public LineMapper<item> lineMapper() {
//		DefaultLineMapper<item> defaultLineMapper = new DefaultLineMapper<item>();
//		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
//
//		lineTokenizer.setDelimiter(",");
//		lineTokenizer.setStrict(false);
//		lineTokenizer.setNames(new String[] { "iditem", "category", "description", "expire_date", "name", "price",
//				"stock_id", "sup_id", "type" });
//		BeanWrapperFieldSetMapper<item> fieldSetMapper = new BeanWrapperFieldSetMapper<item>();
//		fieldSetMapper.setTargetType(item.class);
//		defaultLineMapper.setLineTokenizer(lineTokenizer);
//		defaultLineMapper.setFieldSetMapper(fieldSetMapper);
//
//		return defaultLineMapper;
//
//	}
//
//	public ItemWriter<item> demoJobWriter() {
//		FlatFileItemWriter<item> writer = new FlatFileItemWriter<>();
//
//		writer.setResource(new ClassPathResource("item.csv"));
//		DelimitedLineAggregator<item> delLineAgg = new DelimitedLineAggregator<>();
//		delLineAgg.setDelimiter(",");
//		BeanWrapperFieldExtractor<item> fieldExtractor = new BeanWrapperFieldExtractor<>();
//		fieldExtractor.setNames(new String[] { "iditem", "category", "description", "expire_date", "name", "price",
//				"stock_id", "sup_id", "type" });
//		delLineAgg.setFieldExtractor(fieldExtractor);
//		writer.setLineAggregator(delLineAgg);
//		return writer;
//	}

	
	public JpaPagingItemReader<item> demoJobReader() throws Exception {
		String jpqlQuery = "SELECT p from com.thilini.springBatch.model.item p";

		JpaPagingItemReader<item> reader = new JpaPagingItemReader<>();
		reader.setQueryString(jpqlQuery);
		reader.setEntityManagerFactory(entityManagerFactory);
		reader.setPageSize(1000);
		reader.afterPropertiesSet();
		reader.setSaveState(true);
		

		return reader;

	}
	
	@Bean
	public Processor processer() {
		System.out.println("processing...");
		return new Processor();
	}
	
	@Bean
	public DBWriter write() throws UnexpectedInputException, ParseException, Exception {
		System.out.println("writing...");
		
		return new DBWriter();
	}

}
