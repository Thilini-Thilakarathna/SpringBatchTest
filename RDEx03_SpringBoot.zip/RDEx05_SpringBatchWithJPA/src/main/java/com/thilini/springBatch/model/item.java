package com.thilini.springBatch.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class item {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer iditem;
	
	public Integer getIditem() {
		return iditem;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public LocalDateTime getExpireDate() {
		return expireDate;
	}
	public Double getPrice() {
		return price;
	}
	public String getCategory() {
		return category;
	}
	public String getType() {
		return type;
	}
	public String getStockId() {
		return stockId;
	}
	public void setIditem(Integer iditem) {
		this.iditem = iditem;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setExpireDate(LocalDateTime expireDate) {
		this.expireDate = expireDate;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setStockId(String stockId) {
		this.stockId = stockId;
	}
	String name;
	String description;
	LocalDateTime expireDate;
	Double price;
	String category;
	String type;
	String stockId;
	
	
	Integer sup_id;

	public Integer getSup_id() {
		return sup_id;
	}
	public void setSup_id(Integer sup_id) {
		this.sup_id = sup_id;
	}
}
