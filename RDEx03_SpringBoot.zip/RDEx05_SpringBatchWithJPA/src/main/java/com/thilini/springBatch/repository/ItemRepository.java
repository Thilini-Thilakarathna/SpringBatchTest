package com.thilini.springBatch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.thilini.springBatch.model.item;

public interface ItemRepository extends JpaRepository<item, Integer>{

	
	
}
