package com.thilini.springBatch.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.thilini.springBatch.model.item;
import com.thilini.springBatch.repository.ItemRepository;

@Component
public class DBWriter implements ItemWriter<item>{

	
	public DBWriter() {
		System.out.println("writing....");
	}
	
	
	@Autowired
	private ItemRepository itemRepository;
	
	
	@Override
	public void write(List<? extends item> itm) throws Exception {
		
		System.out.println("Saving"+itm);
		itemRepository.saveAll(itm);
	}

}
