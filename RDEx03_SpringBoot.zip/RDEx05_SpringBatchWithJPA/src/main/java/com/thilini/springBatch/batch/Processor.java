package com.thilini.springBatch.batch;
import javax.batch.api.chunk.listener.ItemProcessListener;

import org.aspectj.lang.annotation.Before;
import org.springframework.batch.core.annotation.BeforeProcess;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.thilini.springBatch.model.item;

@Component
public class Processor implements ItemProcessor<item, item>,ItemProcessListener{

	
	
	
	@Override
	public item process(item item) throws Exception {
		
		
		System.out.println(item.getName());
		
		return item;
	}

	@BeforeProcess
	public void beforeProcess(Object item) throws Exception {
		System.out.println("before"+item);
		
	}

	@Override
	public void afterProcess(Object item, Object result) throws Exception {
		System.out.println("after");
		
	}

	@Override
	public void onProcessError(Object item, Exception ex) throws Exception {
		System.out.println("error");
		
	}

}
