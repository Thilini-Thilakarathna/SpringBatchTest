package com.thilini.springBatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RdEx05SpringBatchWithJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RdEx05SpringBatchWithJpaApplication.class, args);
	}

}
