export class Items {
id:number;
name:String;
des:String;
price:number;




}
