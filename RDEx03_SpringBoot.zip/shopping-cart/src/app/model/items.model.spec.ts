import { Items } from './items.model';

describe('Items', () => {
  it('should create an instance', () => {
    expect(new Items()).toBeTruthy();
  });
});
