export class Product {
   id: number;
  name: String;
  des: String;
  img: String;
  price: number;
  
  
}
