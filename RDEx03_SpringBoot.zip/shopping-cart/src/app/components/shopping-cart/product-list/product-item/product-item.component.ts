import { Component, OnInit } from '@angular/core';


import { HttpClientService } from 'src/app/service/http-client.service';
import { Items } from 'src/app/model/items.model';
import { Product } from 'src/app/model/product';
import { CookieService } from 'ngx-cookie-service';
import { StorageMap, LocalStorage } from '@ngx-pwa/local-storage';
import { NavbarComponent } from 'src/app/components/shared/navbar/navbar.component';


@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.scss']
})
export class ProductItemComponent implements OnInit {


  products: Product[] = [];
  cartProduct: []
  cookieService: CookieService;
  items: Items[] = JSON.parse(localStorage.getItem('product'));
  status: boolean = false;
  Item: any = {}

  produt: Product[] = [];
  constructor(private httpClientService: HttpClientService) {


  }

  ngOnInit() {
    // this.httpClientService.getItem().subscribe(
    //   responce => this.employees=responce);

    this.httpClientService.getItem().subscribe(responce => {

      console.log(responce);
      return this.products = responce;



    })

    // this.httpClientService.getItem().subscribe(response => this.handlesSuccessfulResponse(response));


  }

  handlesSuccessfulResponse(response) {

  }


  AddToCartFunction(product: Product) {
    //  this.storageMap.set('product',product);
    //  console.log(this.storageMap.get('product'));

    // localStorage.setItem('product',JSON.stringify(product).concat("                 ").concat(localStorage.getItem('product')));
    console.log(localStorage.getItem('product'));



    // this.produt.push(product);

    this.Item = { "id": product.id, "name": product.name, "des": product.des, "price": product.price };

    if (localStorage.getItem('product') !== null) {

      let prduct: Items[] = JSON.parse(localStorage.getItem('product'))

      if (prduct.find(element => element.id == product.id)) {

      } else {
        this.items.push(this.Item);
      }



    } else {

      this.items = []

      this.items.push(this.Item);

    }





    console.log(this.items);



    localStorage.setItem('product', JSON.stringify(this.items))
    this.httpClientService.fetchCountOfLocalStorage();



  }
}
