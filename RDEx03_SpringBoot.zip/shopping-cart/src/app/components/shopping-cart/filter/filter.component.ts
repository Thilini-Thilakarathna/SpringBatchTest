import { Component, OnInit } from '@angular/core';
import { HttpClientService } from 'src/app/service/http-client.service';
import { Type } from 'src/app/model/type.model';
import { MatDialogRef } from '@angular/material';
import { Items } from 'src/app/model/items.model';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {

public postData;

types : Type[]=[];
items: Items[]=[];

public total: number= 0;
  constructor(private httpClientService: HttpClientService, public dialogRef: MatDialogRef<FilterComponent> ) { }

  ngOnInit() {
    this.items= this.httpClientService.localStorageProduct
    this.calculateTotal();
  
  }



  OnChangeType(even:String){
    let event= even;
    console.log(event);
    
    this.httpClientService.addInvoice("http://localhost:8080/emscloud/type",event).subscribe(data =>{
      this.postData=data;
      console.log(this.postData);
     
    })

  }

  close(){
  this.dialogRef.close();
  }


  calculateTotal(){
    console.log(this.total)
   let prduct:Items[]=this.httpClientService.localStorageProduct
   console.log(prduct)
    // for (let index = 0; index < prduct.length; index++) {
    
    // this.total = this.total+ prduct..price
    // 
    // }
prduct.forEach(element => {
  console.log(element);
  this.total= this.total+  element.price;
  console.log(this.total);
});
console.log(this.total);
  }
}
