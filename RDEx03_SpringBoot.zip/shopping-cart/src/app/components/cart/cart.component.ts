import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';
import { LocalStorage } from '@ngx-pwa/local-storage';
import { HttpClientService } from 'src/app/service/http-client.service';
import { Items } from 'src/app/model/items.model';
import { ProductItemComponent } from '../shopping-cart/product-list/product-item/product-item.component';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { FilterComponent } from '../shopping-cart/filter/filter.component';
import { all } from 'q';




// import { Popup } from 'ng2-opd-popup';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  items: Items;
  public postData;
  total: number = 0;
  itms: Items[] = JSON.parse(localStorage.getItem('product'));

  constructor(private httpClientService: HttpClientService, private dialog: MatDialog
  ) { }

  ngOnInit() {
    this.total=0;
    this.calculateTotal();
  }


  public addInvoice() {
    this.openReport();
    let item: any = this.httpClientService.localStorageProduct
    console.log(item);

    this.httpClientService.addInvoice("http://localhost:8080/emscloud/invoice", item).subscribe(data => {
      this.postData = data;
      console.log(this.postData);
      this.httpClientService.localStorageProduct = []
      localStorage.removeItem('product')
      this.total = 0;
    })

    // this.popup.show();
  }

  openReport() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "65%";
    dialogConfig.width = "100%";
    this.dialog.open(FilterComponent, dialogConfig);
  }
  deleteCart(index) {
    console.log( this.itms)
    console.log(this.itms[index])
  this.httpClientService.localStorageProduct.splice(index,1)
 
  localStorage.setItem('product', JSON.stringify(this.httpClientService.localStorageProduct))
  //  this.total-=this.itms[index].id
  
   this.ngOnInit();
  }
  calculateTotal() {
    console.log(this.total)
    let prduct: Items[] = this.httpClientService.localStorageProduct
    console.log(prduct)
    // for (let index = 0; index < prduct.length; index++) {

    // this.total = this.total+ prduct..price
    // 
    // }
    
    prduct.forEach(element => {
      console.log(element);
      
      this.total = this.total + element.price;
    
      console.log(this.total);
    });
    console.log(this.total);
  }
}
