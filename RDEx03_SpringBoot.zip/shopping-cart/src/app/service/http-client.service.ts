import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http'
import { Items } from '../model/items.model';
import { ProductItemComponent } from '../components/shopping-cart/product-list/product-item/product-item.component';
import { Product } from '../model/product';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { resolve } from 'url';
import { Type } from '../model/type.model';




@Injectable({
  providedIn: 'root'
})


export class HttpClientService {

  constructor(private httpClient: HttpClient) { 

this.httpOptions= {
  headers: new HttpHeaders(
    {'Content-Type':'application/json; Charset=utf-8'}
  )
}


  }
  product: Product[] = [];
 type: Type[]=[];
 localStorageProduct: Product[]=[];
 localStorageProductCount:number=0;
public httpOptions:any;



  getItem() {
    let response;

    return this.httpClient.get<Product[]>('http://localhost:8080/emscloud/product');
    //  this.httpClient.get('http://localhost:8080/ShCartServer/ItemController').subscribe(res => {
    //    console.log("in http client",res)
    //    response=res;
    //   // this.product=response.Product as Product[];
    // this.product=response;
    //  });
  }

  getType(){
    let response;
    return this.httpClient.get<Type[]>('http://localhost:8080/emscloud/type');

  }


fetchCountOfLocalStorage(){
  this.localStorageProduct=JSON.parse(localStorage.getItem('product'));
 
  this.localStorageProductCount= this.localStorageProduct.length;
}

addInvoice(url:string,Item:any){
return this.httpClient.post(url,Item,this.httpOptions);
}

}
