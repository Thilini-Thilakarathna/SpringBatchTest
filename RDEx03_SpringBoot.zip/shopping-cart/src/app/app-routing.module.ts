import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ProductItemComponent} from './components/shopping-cart/product-list/product-item/product-item.component'
import { FilterComponent } from './components/shopping-cart/filter/filter.component';
import { CartComponent } from './components/cart/cart.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart/shopping-cart.component';

const routes: Routes = [
  { path: '',
  redirectTo: '/shopping-cart',
  pathMatch: 'full'
},
  {path:'shopping-cart',component:ShoppingCartComponent},
  {path: 'cart', component:CartComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
