import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class main {
	
public static void main(String[] args) {
	
	
	
	ApplicationContext ctx= new ClassPathXmlApplicationContext("springConfig.xml");
	
	Bookshop bs= (Bookshop) ctx.getBean("BookshopBean");
	bs.books();
	
	((AbstractApplicationContext)ctx).registerShutdownHook();
	
	
}
}
