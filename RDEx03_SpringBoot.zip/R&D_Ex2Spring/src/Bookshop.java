
public class Bookshop {
	
	public Supplier getSupplier() {
		return supplier;
	}


	Supplier supplier;
	public Bookshop() {}
	public Bookshop(Supplier supplier) {
		
		this.supplier = supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	
	
	public void books() {
		supplier.supplyBooks();
	}

}
