
public interface Supplier {

	
	public abstract void supplyBooks();
	
	
}
