
public class Notebook implements Supplier{

	@Override
	public void supplyBooks() {
		System.out.println("WE SUPPLY NOTEBOOKS FOR YOU!!!");
		
	}

}
