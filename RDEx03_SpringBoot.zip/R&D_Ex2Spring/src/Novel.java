
public class Novel implements Supplier{

	@Override
	public void supplyBooks() {
		System.out.println("WE SUPPLY NOVELS FOR YOU!!!");
		
	}

}
