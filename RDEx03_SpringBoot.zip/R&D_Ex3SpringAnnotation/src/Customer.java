import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;



@Configuration	
@ComponentScan(basePackageClasses = Restaurant.class)
public class Customer {
	

public static void main(String[] args) {
	
	try {
		AnnotationConfigApplicationContext contex= new AnnotationConfigApplicationContext(Customer.class);
		
		System.out.println(contex);
		
	//	Restaurant rest= new Restaurant();
		Restaurant rest=  contex.getBean(Restaurant.class);
		
		System.out.println(contex);
		
	rest.m();
		contex.close();
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
}
