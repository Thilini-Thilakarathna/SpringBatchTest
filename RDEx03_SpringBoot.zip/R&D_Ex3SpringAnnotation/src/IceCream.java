import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Qualifier("IceCreamBean")
public class IceCream implements FreeItem{

	@Override
	public void free() {
	System.out.println("YOU HAVE A FREE ICE CREAM");
		
	}

}
