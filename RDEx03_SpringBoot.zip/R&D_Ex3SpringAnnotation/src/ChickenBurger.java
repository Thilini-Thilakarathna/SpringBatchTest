import org.springframework.stereotype.Component;

@Component
public class ChickenBurger implements Pastry{

	@Override
	public void pastry() {
		System.out.println("WE ARE MAKING CHICKEN BURGER FOR YOU!!!");
		
	}

}
