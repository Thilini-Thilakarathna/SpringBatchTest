
public interface Pastry {

	
	public abstract void pastry();
}
