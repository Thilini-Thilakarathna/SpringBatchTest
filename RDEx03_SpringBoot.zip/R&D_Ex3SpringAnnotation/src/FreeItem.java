
public interface FreeItem {

	
	public abstract void free();
}
