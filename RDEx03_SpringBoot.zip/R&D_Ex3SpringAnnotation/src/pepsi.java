import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component
@Qualifier("pepsiBean")
public class pepsi implements FreeItem{

	@Override
	public void free() {
		System.out.println("YOU HAVE A FREE PEPSI");
		
	}

}
