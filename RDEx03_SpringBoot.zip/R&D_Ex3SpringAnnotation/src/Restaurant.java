import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


@Service
public class Restaurant {

	
	@Autowired
	@Qualifier("pepsiBean")
	private FreeItem freeItem;
	
	
	public void m() {
		freeItem.free();
	}
}
