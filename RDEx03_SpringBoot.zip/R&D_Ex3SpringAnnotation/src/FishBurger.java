import org.springframework.stereotype.Component;

@Component
public class FishBurger implements Pastry{

	@Override
	public void pastry() {
		System.out.println("WE ARE MAKING FISH BURGER FOR YOU !!!");
		
	}

}
